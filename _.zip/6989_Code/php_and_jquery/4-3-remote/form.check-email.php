<?php
if(isset($_GET['email']) && $_GET['email']=='kae@verens.com')echo 'false';
else echo 'true';
