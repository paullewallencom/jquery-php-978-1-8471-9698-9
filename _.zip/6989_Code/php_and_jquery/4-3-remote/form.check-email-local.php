<?php
if($value=='kae@verens.com')return false;
else return true;
