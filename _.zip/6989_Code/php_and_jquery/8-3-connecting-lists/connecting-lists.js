$(document).ready(function(){
	$('.email_contacts').sortable({
		'connectWith':['.email_contacts']
	});
});
