<?php
$froot='/home/kae/images';
