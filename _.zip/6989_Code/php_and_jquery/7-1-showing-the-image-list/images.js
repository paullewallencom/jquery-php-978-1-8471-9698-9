$(document).ready(function(){
	$("#directory_list").treeview({
		'collapsed':true
	});
});
